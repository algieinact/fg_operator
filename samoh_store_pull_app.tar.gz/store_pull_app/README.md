# SAMOH Store & Pull App

Aplikasi Flutter untuk operator yang mengelola store and pull finish good parts.

## Fitur

### 1. Halaman Login
- Form login dengan username dan password
- Desain modern dengan card putih dan background gradient
- Logo SAMOH yang prominent
- Validasi input dan navigasi ke main menu

### 2. Halaman Main Menu
- Header dengan logo SAMOH dan informasi user
- Timestamp real-time
- 2 menu utama:
  - **Posting F/G**: Untuk posting finish goods (coming soon)
  - **Pulling**: Untuk proses pulling parts

### 3. Halaman Scan/Pulling
- Form input untuk Part No, Rack, dan Scan
- Area image field untuk menampilkan gambar
- Tombol "Scan Rack" dengan icon QR code
- Layout responsive dan user-friendly

## Struktur Proyek

```
lib/
├── main.dart                 # Entry point aplikasi
└── screens/
    ├── login_screen.dart     # Halaman login
    ├── main_menu_screen.dart # Halaman main menu
    └── scan_screen.dart      # Halaman scan/pulling
```

## Cara Menjalankan

1. Pastikan Flutter SDK sudah terinstall
2. Clone atau download proyek ini
3. Jalankan `flutter pub get` untuk menginstall dependencies
4. Jalankan `flutter run` untuk menjalankan aplikasi

## Desain

Aplikasi ini dibuat berdasarkan desain UI/UX yang diberikan dengan:
- Color scheme: Navy blue (#1E3A8A) sebagai primary color
- Typography: Roboto font family
- Layout: Modern card-based design dengan spacing yang konsisten
- Icons: Material Design icons

## Teknologi

- **Framework**: Flutter 3.24.3
- **Language**: Dart 3.5.3
- **Platform**: Android & iOS ready

## Status Pengembangan

✅ Halaman Login - Selesai
✅ Halaman Main Menu - Selesai  
✅ Halaman Scan/Pulling - Selesai
✅ Navigasi antar halaman - Selesai
⏳ Integrasi dengan backend Laravel - Pending
⏳ Fungsi scan QR code - Pending
⏳ Upload dan display image - Pending

## Catatan

Aplikasi ini siap untuk dikembangkan lebih lanjut dengan:
1. Integrasi API backend Laravel
2. Implementasi camera/QR scanner
3. Image upload dan display functionality
4. Data persistence dan state management
5. Error handling dan loading states
